﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace home_rental
{
    public partial class Form2 : Form
    {
        MySqlConnection con = new MySqlConnection(@"server=localhost;user id=root;database=home_rental");

        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            try
            {
                string myConnection = "datasource=localhost;port=3306;username=root;password=root";
                MySqlConnection myConn = new MySqlConnection(myConnection);
                string query = "INSERT INTO home_rental.customer(Name,Cust_id,gender,dob,occupation,status,email_id,address) VALUES ('" + this.textBox1.Text + "','" + this.textBox2.Text + "','" + this.textBox3.Text + "','" + this.textBox4.Text + "','" + this.textBox5.Text + "','" + this.textBox6.Text + "','" + this.textBox7.Text + "','" + this.textBox8.Text + "');";
                MySqlCommand selectcmd = new MySqlCommand(query, myConn);

                MySqlDataReader myRead;
                myConn.Open();
                myRead = selectcmd.ExecuteReader();
                MessageBox.Show("Insert succesfully");
                display();
               


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try

            {

                string MyConnection2 = "datasource=localhost;port=3306;username=root;password=root";

                //Display query 

                string Query = "update home_rental.customer set Name='"+textBox1.Text+"',gender='"+textBox3.Text+"',dob='"+textBox4.Text+"',occupation='"+textBox5.Text+"',Status='"+textBox6.Text+"',Email_id='"+textBox7.Text+"',Address='"+textBox8.Text+"'where cust_id='" + textBox2.Text + "' ";

                MySqlConnection MyConn2 = new MySqlConnection(MyConnection2);

                MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);
                



                //  MyConn2.Open(); 

                //For offline connection we weill use  MySqlDataAdapter class. 

                MySqlDataAdapter MyAdapter = new MySqlDataAdapter();

                MyAdapter.SelectCommand = MyCommand2;

                DataTable dTable = new DataTable();

                MyAdapter.Fill(dTable);
                





                dataGridView1.DataSource = dTable; // here i have assign dTable object to the dataGridView1 object to display data. 
                display();


                // MyConn2.Close(); 

            }

            catch (Exception ex)


            {



                MessageBox.Show(ex.Message);

            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            try

            {

                string MyConnection2 = "datasource=localhost;port=3306;username=root;password=root";

                string Query = "delete from home_rental.customer where cust_id ='" + this.textBox2.Text + "';";

                MySqlConnection MyConn2 = new MySqlConnection(MyConnection2);

                MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);

                MySqlDataReader MyReader2;

                MyConn2.Open();

                MyReader2 = MyCommand2.ExecuteReader();

                MessageBox.Show("Data Deleted Successfully");
                display();

                while (MyReader2.Read())

                {



                }

                MyConn2.Close();

            }

            catch (Exception ex)

            {



                MessageBox.Show(ex.Message);

            }
            
        }
        public void display()
        {

            try

            {

                string MyConnection2 = "datasource=localhost;port=3306;username=root;password=root";

                //Display query 

                string Query = "select * from home_rental.customer ";

                MySqlConnection MyConn2 = new MySqlConnection(MyConnection2);

                MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);



                //  MyConn2.Open(); 

                //For offline connection we weill use  MySqlDataAdapter class. 

                MySqlDataAdapter MyAdapter = new MySqlDataAdapter();

                MyAdapter.SelectCommand = MyCommand2;

                DataTable dTable = new DataTable();

                MyAdapter.Fill(dTable);





                dataGridView1.DataSource = dTable; // here i have assign dTable object to the dataGridView1 object to display data. 



                // MyConn2.Close(); 

            }

            catch (Exception ex)


            {



                MessageBox.Show(ex.Message);

            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            display();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1a f2 = new Form1a();
            f2.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form3 f2 = new Form3();
            f2.Show();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void button7_Click(object sender, EventArgs e)
        {
            textBox1.Text = " ";
            textBox2.Text = " ";
            textBox3.Text = " ";
            textBox4.Text = " ";
            textBox5.Text = " ";
            textBox6.Text = " ";
            textBox7.Text = " ";
            textBox8.Text = " ";
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged_1(object sender, EventArgs e)
        {

        }

        private void button8_Click(object sender, EventArgs e)
        {

            try

            {

                string MyConnection2 = "datasource=localhost;port=3306;username=root;password=root";

                //Display query 

                string Query = "select * from home_rental.customer where cust_id='" + this.textBox2.Text + "' ";

                MySqlConnection MyConn2 = new MySqlConnection(MyConnection2);

                MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);




                //  MyConn2.Open(); 

                //For offline connection we weill use  MySqlDataAdapter class. 

                MySqlDataAdapter MyAdapter = new MySqlDataAdapter();

                MyAdapter.SelectCommand = MyCommand2;

                DataTable dTable = new DataTable();

                MyAdapter.Fill(dTable);






                dataGridView1.DataSource = dTable; // here i have assign dTable object to the dataGridView1 object to display data. 



                MyConn2.Close();

            }

            catch (Exception ex)


            {



                MessageBox.Show(ex.Message);

            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
