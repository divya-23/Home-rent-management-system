﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace home_rental
{
    public partial class Form3 : Form
    {
        MySqlConnection con = new MySqlConnection(@"server=localhost;user id=root;database=home_rental");

        public Form3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string myConnection = "datasource=localhost;port=3306;username=root;password=root";
                MySqlConnection myConn = new MySqlConnection(myConnection);
                string query = "INSERT INTO home_rental.Owner_details (Name,Owner_id,Gender,DOB,Occupation,Status,Email_id,Address) VALUES ('" + this.textBox1.Text + "','" + this.textBox2.Text + "','" + this.textBox3.Text + "','" + this.textBox4.Text + "','" + this.textBox5.Text + "','" + this.textBox6.Text + "','" + this.textBox7.Text + "','" + this.textBox8.Text + "');";
                MySqlCommand selectcmd = new MySqlCommand(query, myConn);

                MySqlDataReader myRead;
                myConn.Open();
                myRead = selectcmd.ExecuteReader();
                MessageBox.Show("sucess");
                display();



            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try

            {

                string MyConnection2 = "datasource=localhost;port=3306;username=root;password=root";

                //Display query 

                string Query = "update home_rental.owner_details set Name='" + textBox1.Text + "',Gender='" + textBox3.Text + "',DOB='"+ textBox4.Text +"',Occupation='"+ textBox5.Text +"',Status='"+ textBox6.Text+"',Email_id='"+textBox7.Text+"',Address='"+textBox8.Text+"'where Owner_id='" + textBox2.Text + "' ";

                MySqlConnection MyConn2 = new MySqlConnection(MyConnection2);

                MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);




                //  MyConn2.Open(); 

                //For offline connection we weill use  MySqlDataAdapter class. 

                MySqlDataAdapter MyAdapter = new MySqlDataAdapter();

                MyAdapter.SelectCommand = MyCommand2;

                DataTable dTable = new DataTable();

                MyAdapter.Fill(dTable);






                dataGridView1.DataSource = dTable; // here i have assign dTable object to the dataGridView1 object to display data. 
                display();


                // MyConn2.Close(); 

            }

            catch (Exception ex)


            {



                MessageBox.Show(ex.Message);

            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try

            {

                string MyConnection2 = "datasource=localhost;port=3306;username=root;password=root";

                string Query = "delete from home_rental.owner_details where Owner_id ='" + this.textBox2.Text + "';";

                MySqlConnection MyConn2 = new MySqlConnection(MyConnection2);

                MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);

                MySqlDataReader MyReader2;

                MyConn2.Open();

                MyReader2 = MyCommand2.ExecuteReader();

                MessageBox.Show("Data Deleted");
                display();

                while (MyReader2.Read())

                {



                }

                MyConn2.Close();

            }

            catch (Exception ex)

            {



                MessageBox.Show(ex.Message);

            }


        }
        public void display()
        {

            try

            {

                string MyConnection2 = "datasource=localhost;port=3306;username=root;password=root";

                //Display query 

                string Query = "select * from home_rental.owner_details ";

                MySqlConnection MyConn2 = new MySqlConnection(MyConnection2);

                MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);



                //  MyConn2.Open(); 

                //For offline connection we weill use  MySqlDataAdapter class. 

                MySqlDataAdapter MyAdapter = new MySqlDataAdapter();

                MyAdapter.SelectCommand = MyCommand2;

                DataTable dTable = new DataTable();

                MyAdapter.Fill(dTable);





                dataGridView1.DataSource = dTable; // here i have assign dTable object to the dataGridView1 object to display data. 



                // MyConn2.Close(); 

            }

            catch (Exception ex)


            {



                MessageBox.Show(ex.Message);

            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            display();   
        }

        private void button5_Click(object sender, EventArgs e)
        {

            this.Hide();
            Form2 f2 = new Form2();
            f2.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {

            this.Hide();
            Form4 f2 = new Form4();
            f2.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            textBox1.Text = " ";
            textBox2.Text = " ";
            textBox3.Text = " ";
            textBox4.Text = " ";
            textBox5.Text = " ";
            textBox6.Text = " ";
            textBox7.Text = " ";
            textBox8.Text = " ";
        }

        private void button8_Click(object sender, EventArgs e)
        {

            try

            {

                string MyConnection2 = "datasource=localhost;port=3306;username=root;password=root";

                //Display query 

                string Query = "select * from home_rental.owner_details where Owner_id='" + this.textBox2.Text + "' ";

                MySqlConnection MyConn2 = new MySqlConnection(MyConnection2);

                MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);




                //  MyConn2.Open(); 

                //For offline connection we weill use  MySqlDataAdapter class. 

                MySqlDataAdapter MyAdapter = new MySqlDataAdapter();

                MyAdapter.SelectCommand = MyCommand2;

                DataTable dTable = new DataTable();

                MyAdapter.Fill(dTable);






                dataGridView1.DataSource = dTable; // here i have assign dTable object to the dataGridView1 object to display data. 



                MyConn2.Close();

            }

            catch (Exception ex)


            {



                MessageBox.Show(ex.Message);

            }
        }
    }
}
