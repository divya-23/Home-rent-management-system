﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace home_rental
{
    public partial class Form1 : Form
    {
MySqlConnection con = new MySqlConnection(@"server=localhost;user id=root;database=home_rental");

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (this.textBox1.Text == "")
            {
                MessageBox.Show("Please Enter Username....");
            }
            if (this.textBox2.Text == "")
            {
                MessageBox.Show("Please Enter password....");
            }
            if (this.textBox1.Text.Length == 0  || this.textBox2.Text.Length == 0)
            {
                MessageBox.Show("All Fields are Compulsary / Mandatory....");
            }
           
                string myConnection = "datasource=localhost;port=3306;username=root;password=root";
            string Username = this.textBox1.Text.ToString();
            string password = this.textBox2.Text.ToString();
                MySqlConnection myConn = new MySqlConnection(myConnection);
                myConn.Open();
                string query = "select * from home_rental.login where Username='"+Username+"' and password='"+password+"' ";
                MySqlDataAdapter sda = new MySqlDataAdapter(query, myConn);
                DataTable dt = new DataTable();
                sda.Fill(dt);

                if (dt.Rows.Count == 1)
                {
                    MessageBox.Show("Valid Username...." + Username);
                this.Hide();
                Form1a f1 = new Form1a();
                f1.Show();
                }
                else {
                    MessageBox.Show(" Invalid username...."+Username);
                }

            myConn.Close();


            
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                string myConnection = "datasource=localhost;port=3306;username=root;password=root";
                MySqlConnection myConn = new MySqlConnection(myConnection);
                string query = "INSERT INTO home_rental.login(Username,password) VALUES ('" + this.textBox1.Text + "','" + this.textBox2.Text + "');";
                MySqlCommand selectcmd = new MySqlCommand(query, myConn);

                MySqlDataReader myRead;
                myConn.Open();
                myRead = selectcmd.ExecuteReader();
                MessageBox.Show("Registered succesfully");
                



            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try

            {

                string MyConnection2 = "datasource=localhost;port=3306;username=root;password=root";

                string Query = "delete from home_rental.login where Username ='" + this.textBox1.Text + "';";

                MySqlConnection MyConn2 = new MySqlConnection(MyConnection2);

                MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);

                MySqlDataReader MyReader2;

                MyConn2.Open();

                MyReader2 = MyCommand2.ExecuteReader();

                MessageBox.Show("Logout Successfully");
                

                while (MyReader2.Read())

                {



                }

                MyConn2.Close();

            }

            catch (Exception ex)

            {



                MessageBox.Show(ex.Message);

            }
        }
    }
}
