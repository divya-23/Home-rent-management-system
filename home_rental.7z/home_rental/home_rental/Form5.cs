﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace home_rental
{
    public partial class Form5 : Form
    {
        MySqlConnection con = new MySqlConnection(@"server=localhost;user id=root;database=home_rental");

        public Form5()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string myConnection = "datasource=localhost;port=3306;username=root;password=root";
                MySqlConnection myConn = new MySqlConnection(myConnection);
                string query = "INSERT INTO home_rental.rent_house_type (Owner_id,1bhk,2bhk,3bhk,4bhk) VALUES ('" + this.textBox1.Text + "','" + this.textBox2.Text + "','" + this.textBox3.Text + "','" + this.textBox4.Text + "','" + this.textBox5.Text + "');";
                MySqlCommand selectcmd = new MySqlCommand(query, myConn);

                MySqlDataReader myRead;
                myConn.Open();
                myRead = selectcmd.ExecuteReader();
                MessageBox.Show("sucess");
                display();



            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            try

            {

                string MyConnection2 = "datasource=localhost;port=3306;username=root;password=root";

                //Display query 

                string Query = "update home_rental.rent_house_type set 1bhk='" + textBox2.Text + "',2bhk='" + textBox3.Text + "',3bhk='" + textBox4.Text + "',4bhk='" + textBox5.Text + "'where Owner_id='" + textBox1.Text + "' ";

                MySqlConnection MyConn2 = new MySqlConnection(MyConnection2);

                MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);




                //  MyConn2.Open(); 

                //For offline connection we weill use  MySqlDataAdapter class. 

                MySqlDataAdapter MyAdapter = new MySqlDataAdapter();

                MyAdapter.SelectCommand = MyCommand2;

                DataTable dTable = new DataTable();

                MyAdapter.Fill(dTable);






                dataGridView1.DataSource = dTable; // here i have assign dTable object to the dataGridView1 object to display data. 
                display();


                // MyConn2.Close(); 

            }

            catch (Exception ex)


            {



                MessageBox.Show(ex.Message);

            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            try

            {

                string MyConnection2 = "datasource=localhost;port=3306;username=root;password=root";

                string Query = "delete from home_rental.rent_house_type where Owner_id ='" + this.textBox1.Text + "';";

                MySqlConnection MyConn2 = new MySqlConnection(MyConnection2);

                MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);

                MySqlDataReader MyReader2;

                MyConn2.Open();

                MyReader2 = MyCommand2.ExecuteReader();

                MessageBox.Show("Data Deleted");
                display();

                while (MyReader2.Read())

                {



                }

                MyConn2.Close();

            }

            catch (Exception ex)

            {



                MessageBox.Show(ex.Message);

            }
        }
        public void display()
        {

            try

            {

                string MyConnection2 = "datasource=localhost;port=3306;username=root;password=root";

                //Display query 

                string Query = "select * from home_rental.rent_house_type ";

                MySqlConnection MyConn2 = new MySqlConnection(MyConnection2);

                MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);



                //  MyConn2.Open(); 

                //For offline connection we weill use  MySqlDataAdapter class. 

                MySqlDataAdapter MyAdapter = new MySqlDataAdapter();

                MyAdapter.SelectCommand = MyCommand2;

                DataTable dTable = new DataTable();

                MyAdapter.Fill(dTable);





                dataGridView1.DataSource = dTable; // here i have assign dTable object to the dataGridView1 object to display data. 



                // MyConn2.Close(); 

            }

            catch (Exception ex)


            {



                MessageBox.Show(ex.Message);

            }
        }
        private void button4_Click(object sender, EventArgs e)
        {
            display();
        }

        private void button5_Click(object sender, EventArgs e)
        {

            this.Hide();
            Form4 f2 = new Form4();
            f2.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {

            this.Hide();
            Form6 f2 = new Form6();
            f2.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            textBox1.Text = " ";
            textBox2.Text = " ";
            textBox3.Text = " ";
            textBox4.Text = " ";
            textBox5.Text = " ";
        }

       

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void button8_Click(object sender, EventArgs e)
        {
            try

            {

                string MyConnection2 = "datasource=localhost;port=3306;username=root;password=root";

                //Display query 

                string Query = "select * from home_rental.rent_house_type where Owner_id='" + this.textBox1.Text + "' ";

                MySqlConnection MyConn2 = new MySqlConnection(MyConnection2);

                MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);




                //  MyConn2.Open(); 

                //For offline connection we weill use  MySqlDataAdapter class. 

                MySqlDataAdapter MyAdapter = new MySqlDataAdapter();

                MyAdapter.SelectCommand = MyCommand2;

                DataTable dTable = new DataTable();

                MyAdapter.Fill(dTable);






                dataGridView1.DataSource = dTable; // here i have assign dTable object to the dataGridView1 object to display data. 



                MyConn2.Close();

            }

            catch (Exception ex)


            {



                MessageBox.Show(ex.Message);

            }
        }
    }
}
