﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;


namespace home_rental
{
    public partial class Form7 : Form
    {
        MySqlConnection con = new MySqlConnection(@"server=localhost;user id=root;database=home_rental");
        public Form7()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            try

            {

                string MyConnection2 = "datasource=localhost;port=3306;username=root;password=root";

                //Display query 

                string Query = "select * from home_rental.customer ";

                MySqlConnection MyConn2 = new MySqlConnection(MyConnection2);

                MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);




                //  MyConn2.Open(); 

                //For offline connection we weill use  MySqlDataAdapter class. 

                MySqlDataAdapter MyAdapter = new MySqlDataAdapter();

                MyAdapter.SelectCommand = MyCommand2;

                DataTable dTable = new DataTable();

                MyAdapter.Fill(dTable);






                dataGridView1.DataSource = dTable; // here i have assign dTable object to the dataGridView1 object to display data. 



                MyConn2.Close();

            }

            catch (Exception ex)


            {



                MessageBox.Show(ex.Message);

            }
        }

        private void label2_Click(object sender, EventArgs e)
        {
            try

            {

                string MyConnection2 = "datasource=localhost;port=3306;username=root;password=root";

                //Display query 

                string Query = "select * from home_rental.owner_details ";

                MySqlConnection MyConn2 = new MySqlConnection(MyConnection2);

                MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);




                //  MyConn2.Open(); 

                //For offline connection we weill use  MySqlDataAdapter class. 

                MySqlDataAdapter MyAdapter = new MySqlDataAdapter();

                MyAdapter.SelectCommand = MyCommand2;

                DataTable dTable = new DataTable();

                MyAdapter.Fill(dTable);






                dataGridView1.DataSource = dTable; // here i have assign dTable object to the dataGridView1 object to display data. 



                MyConn2.Close();

            }

            catch (Exception ex)


            {



                MessageBox.Show(ex.Message);

            }
        }

        private void label3_Click(object sender, EventArgs e)
        {
            try

            {

                string MyConnection2 = "datasource=localhost;port=3306;username=root;password=root";

                //Display query 

                string Query = "select Name,Address,Occupation from home_rental.owner_details where Address='"+this.textBox1.Text+"' ";

                MySqlConnection MyConn2 = new MySqlConnection(MyConnection2);

                MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);




                //  MyConn2.Open(); 

                //For offline connection we weill use  MySqlDataAdapter class. 

                MySqlDataAdapter MyAdapter = new MySqlDataAdapter();

                MyAdapter.SelectCommand = MyCommand2;

                DataTable dTable = new DataTable();

                MyAdapter.Fill(dTable);






                dataGridView1.DataSource = dTable; // here i have assign dTable object to the dataGridView1 object to display data. 



                MyConn2.Close();

            }

            catch (Exception ex)


            {



                MessageBox.Show(ex.Message);

            }
        }

        private void label4_Click(object sender, EventArgs e)
        {
            try

            {

                string MyConnection2 = "datasource=localhost;port=3306;username=root;password=root";

                //Display query 

                string Query = "select * from home_rental.registration_details where Amount > '5000000' ";

                MySqlConnection MyConn2 = new MySqlConnection(MyConnection2);

                MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);




                //  MyConn2.Open(); 

                //For offline connection we weill use  MySqlDataAdapter class. 

                MySqlDataAdapter MyAdapter = new MySqlDataAdapter();

                MyAdapter.SelectCommand = MyCommand2;

                DataTable dTable = new DataTable();

                MyAdapter.Fill(dTable);






                dataGridView1.DataSource = dTable; // here i have assign dTable object to the dataGridView1 object to display data. 



                MyConn2.Close();

            }

            catch (Exception ex)


            {



                MessageBox.Show(ex.Message);

            }
        }

        private void label5_Click(object sender, EventArgs e)
        {
            try

            {

                string MyConnection2 = "datasource=localhost;port=3306;username=root;password=root";

                //Display query 

                string Query = "select * from home_rental.customer where gender='"+this.textBox2.Text+"' ";

                MySqlConnection MyConn2 = new MySqlConnection(MyConnection2);

                MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);




                //  MyConn2.Open(); 

                //For offline connection we weill use  MySqlDataAdapter class. 

                MySqlDataAdapter MyAdapter = new MySqlDataAdapter();

                MyAdapter.SelectCommand = MyCommand2;

                DataTable dTable = new DataTable();

                MyAdapter.Fill(dTable);






                dataGridView1.DataSource = dTable; // here i have assign dTable object to the dataGridView1 object to display data. 



                MyConn2.Close();

            }

            catch (Exception ex)


            {



                MessageBox.Show(ex.Message);

            }
        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {
            try

            {

                string MyConnection2 = "datasource=localhost;port=3306;username=root;password=root";

                //Display query 

                string Query = "select Registration_id,Owner_id from home_rental.Registration_details where Registration_Satus='" + this.textBox3.Text + "' ";

                MySqlConnection MyConn2 = new MySqlConnection(MyConnection2);

                MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);




                //  MyConn2.Open(); 

                //For offline connection we weill use  MySqlDataAdapter class. 

                MySqlDataAdapter MyAdapter = new MySqlDataAdapter();

                MyAdapter.SelectCommand = MyCommand2;

                DataTable dTable = new DataTable();

                MyAdapter.Fill(dTable);






                dataGridView1.DataSource = dTable; // here i have assign dTable object to the dataGridView1 object to display data. 



                MyConn2.Close();

            }

            catch (Exception ex)


            {



                MessageBox.Show(ex.Message);

            }
        }

        private void label7_Click(object sender, EventArgs e)
        {
            try

            {

                string MyConnection2 = "datasource=localhost;port=3306;username=root;password=root";

                //Display query 

                string Query = "select Owner_id,Location,Rent_House_Status from home_rental.rent_house_details where Rent_House_Status='" + this.textBox4.Text + "' ";

                MySqlConnection MyConn2 = new MySqlConnection(MyConnection2);

                MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);




                //  MyConn2.Open(); 

                //For offline connection we weill use  MySqlDataAdapter class. 

                MySqlDataAdapter MyAdapter = new MySqlDataAdapter();

                MyAdapter.SelectCommand = MyCommand2;

                DataTable dTable = new DataTable();

                MyAdapter.Fill(dTable);






                dataGridView1.DataSource = dTable; // here i have assign dTable object to the dataGridView1 object to display data. 



                MyConn2.Close();

            }

            catch (Exception ex)


            {



                MessageBox.Show(ex.Message);

            }
        }

        private void button5_Click(object sender, EventArgs e)
        {

            this.Hide();
            Form6 f2 = new Form6();
            f2.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Form7_Load(object sender, EventArgs e)
        {

        }
    }
}
